// Import mongoose
const mongoose = require("mongoose");

// Define Quiz Schema
const quizSchema = new mongoose.Schema({
    question: { type: String, required: true },
    options: { type: [String], required: true },
    answer: { type: String, required: true },
});

// Create model from schema
const Quiz = mongoose.model("Quiz", quizSchema);

// Export model
module.exports = Quiz;
