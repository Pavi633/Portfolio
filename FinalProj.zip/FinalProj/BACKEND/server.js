// Import required modules
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const connectDB = require("./DB/db");
const quizRoutes = require("./routes/quizRoutes");

// Load environment variables
dotenv.config();

// Connect to database
connectDB();

// Initialize Express app
const app = express();

// Middleware setup
app.use(cors()); // Enable CORS
app.use(express.json()); // Parse JSON requests

// API routes
app.use("/api/quiz", quizRoutes);

// Test route
app.get("/", (req, res) => {
    res.send("Quiz API is Running 🚀");
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
