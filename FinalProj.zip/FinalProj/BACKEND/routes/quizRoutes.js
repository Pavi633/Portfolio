// Import express and Quiz model
const express = require("express");
const Quiz = require("../model/schema");

// Initialize router
const router = express.Router();

// Route: Get all quiz questions
router.get("/", async (req, res) => {
    try {
        const quizzes = await Quiz.find();
        res.json(quizzes);
    } catch (error) {
        res.status(500).json({ message: "Error fetching questions" });
    }
});

// Route: Add a new quiz question
router.post("/", async (req, res) => {
    try {
        const { question, options, answer } = req.body;
        const newQuiz = new Quiz({ question, options, answer });
        await newQuiz.save();
        res.json(newQuiz);
    } catch (error) {
        res.status(400).json({ message: "Error adding question" });
    }
});

// Export router
module.exports = router;
