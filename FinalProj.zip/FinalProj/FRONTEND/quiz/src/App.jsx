import React, { useState } from "react";
import "./App.css";

// Add more questions
const quizData = [
  { question: "What is the capital of France?", options: ["Berlin", "Madrid", "Paris", "Lisbon"], answer: "Paris" },
  { question: "Which language is used for web development?", options: ["Python", "JavaScript", "C++", "Java"], answer: "JavaScript" },
  { question: "What is the largest planet in our solar system?", options: ["Earth", "Mars", "Jupiter", "Venus"], answer: "Jupiter" },
  //{ question: "Who wrote 'To Kill a Mockingbird'?", options: ["Harper Lee", "J.K. Rowling", "Ernest Hemingway", "Mark Twain"], answer: "Harper Lee" },
  { question: "Which planet is known as the Red Planet?", options: ["Earth", "Mars", "Venus", "Jupiter"], answer: "Mars" },
  //{ question: "What is the square root of 64?", options: ["6", "8", "10", "12"], answer: "8" },
  { question: "What is the symbol for the element Oxygen?", options: ["O", "Ox", "O2", "O3"], answer: "O" },
  { question: "Who painted the Mona Lisa?", options: ["Picasso", "Van Gogh", "Da Vinci", "Michelangelo"], answer: "Da Vinci" },
  { question: "Which country is the Eiffel Tower located in?", options: ["USA", "France", "Germany", "Italy"], answer: "France" },
  { question: "What is the freezing point of water?", options: ["0°C", "32°F", "100°C", "212°F"], answer: "0°C" },
];

function App() {
  const [page, setPage] = useState("welcome");
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [showChocolate, setShowChocolate] = useState(false);
  const [message, setMessage] = useState("");

  const handleAnswerClick = (option) => {
    setSelectedAnswer(option);
  };

  const handleNextQuestion = () => {
    if (selectedAnswer === quizData[currentQuestion].answer) {
      setScore(score + 1);
    }
    setSelectedAnswer(null);

    if (currentQuestion < quizData.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setShowScore(true);
      if (score === 8) {
        setShowChocolate(true);
      } else if (score === 7) {
        setMessage("Great work!😊🎉");
      } else if (score < 4) {
        setMessage("Better luck next time! 🤗");
      } else {
        setMessage("Nice effort!👍");
      }
    }
  };

  return (
    <div className="container">
      {showChocolate && (
        <div className="chocolate-shower">🍫🍫🍫🍫🍫</div>
      )}

      {page === "welcome" ? (
        <div className="welcome-screen">
          <h1>Welcome to the Quiz App</h1>
          <p>Test your knowledge with fun and exciting questions!</p>
          
          <button className="start-btn" onClick={() => setPage("quiz")}>
            Start Quiz
          </button>
          <div className="image-container">
            <img src="https://file.forms.app/sitefile/how-to-create-an-online-quiz-with-formsapp-cover.jpg" alt="Engaging" />
          </div>
        </div>
      ) : (
        <div className="quiz-container">
          <h1>Quiz App</h1>
          {showScore ? (
            <div className="score-section">
              <h2>Your Score: {score} / {quizData.length}</h2>
              <p className="message">{message}</p>
              <button className="restart-btn" onClick={() => window.location.reload()}>
                Restart Quiz
              </button>
            </div>
          ) : (
            <div className="question-section">
              {/* Display question count */}
              <p className="question-count">
                Question {currentQuestion + 1} / {quizData.length}
              </p>

              {/* Display question */}
              <h2 className="question-text">{quizData[currentQuestion].question}</h2>
              
              {/* Display answer options */}
              <div className="options">
                {quizData[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    className={`option-btn ${selectedAnswer === option ? "selected" : ""}`}
                    onClick={() => handleAnswerClick(option)}
                  >
                    {option}
                  </button>
                ))}
              </div>
              <button className="next-btn" onClick={handleNextQuestion} disabled={!selectedAnswer}>
                {currentQuestion === quizData.length - 1 ? "Finish Quiz" : "Next"}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
